# Smile Asana Affirm

A minimal white/light Affirm tab with short teacher-focused reflection paragraphs.

This version uses a Dylan Werner-inspired modern athletic font style.
The reflection copy is original and written for Smile Asana.

## Files

- `index.html`
- `styles.css`
- `app.js`
- `assets/logo.png`
- `assets/logo-wide.png`
- `assets/intro-video.mp4`
- `README.md`

The upload package excludes the large original `assets/IMG_1255.MOV` file so it can be uploaded through GitHub's web interface. The site uses the smaller `assets/intro-video.mp4` instead.
